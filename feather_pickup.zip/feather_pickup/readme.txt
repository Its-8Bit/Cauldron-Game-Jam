Original feather sprite from "RPG Crafting Material Icons" by BizmasterStudios
(https://opengameart.org/content/rpg-crafting-material-icons), Licensed as CC-By 4.0

Animated by YuriNikolai (https://opengameart.org/users/yurinikolai)

Licensed as Cc-By 4.0

Created for a request on the OpenGameArt Discord (https://discord.gg/yDaQ4NcCux)

Enjoy!